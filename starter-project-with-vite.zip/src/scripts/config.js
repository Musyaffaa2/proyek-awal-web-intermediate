const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  MAP_API_KEY: '2mnb7PKHRFEcx9mK9gcc',
};

export default CONFIG;
